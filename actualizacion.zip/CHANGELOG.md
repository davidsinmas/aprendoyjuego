# Historial de cambios

## V2.18.0 — 2026-08-11

- Retos diarios ampliados a los 10 juegos mediante una rotación de 3 actividades por día.
- Cada reto diario elige una dificultad acorde al progreso real de esa actividad.
- Sumas, restas, comparación, palabras y juegos de prelectura usan 5 ejercicios en modo diario; Sopa de letras usa un tablero corto de hasta 3 palabras.
- Los retos diarios ya no marcan niveles normales como completados ni alteran su desbloqueo.
- Se mantiene el premio diario por completar los 3 retos: +10 💎 y +10 XP, además de la recompensa de cada reto.
- Ajustado el anclaje de los accesorios de mano del avatar: espada ligeramente hacia la mano y arriba; escudo acercado a la mano.
- La corrección se ha aplicado directamente a las capas PNG de las tres rarezas para mantener el sistema paper-doll sin calibraciones por objeto.
- Se conservan tienda, inventario, avatar, 24 piezas Guardián Nova, filtros, precios y el resto de mecánicas de V2.17.0.

## V2.17.0 — 2026-08-11

- Corregido el bloqueo heredado de Sopa de letras: cada tablero nuevo vuelve a aceptar selecciones desde el primer toque.
- La corrección reinicia `locked` al iniciar una nueva sopa, sin modificar la mecánica de selección ni el progreso.
- Conservada la base V2.16 de tienda-catálogo: filtros por rareza y categoría, estados de pieza, vista previa, compras, inventario y equipamiento.
- Se mantienen las 24 piezas Guardián Nova, las tres rarezas, el multiplicador global de precios del Modo Padres y el sistema paper-doll 1024 × 1024.
- Se mantienen los 10 juegos educativos, sus niveles, recompensas, progreso, XP, diamantes, retos y Modo Padres.

## V2.16

- Tienda presentada como catálogo visual.
- Filtros por categoría y rareza.
- Estados visibles para piezas bloqueadas, compradas y equipadas.
- Conservadas las mecánicas de avatar, economía y juego.
