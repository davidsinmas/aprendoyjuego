# Aprendo Jugando

Juego educativo web infantil publicado mediante GitHub Pages.

## Actividades

- Sumas
- Restas
- Mayor o menor
- Palabras
- Sopa de letras
- Sonido inicial
- Sonido final
- Construye la palabra
- Ordena sílabas
- Busca la rima

Cada actividad tiene progresión por niveles, recompensas y registro de progreso.

## Retos diarios

Cada día aparecen 3 retos cortos elegidos mediante una rotación entre los 10 juegos. La dificultad se adapta al progreso de cada actividad y completar un reto diario no desbloquea ni marca como hecho un nivel normal.

## Avatar y tienda

El juego incluye el avatar Guardián Nova mediante un sistema paper-doll con capas prealineadas de 1024 × 1024, inventario y tienda-catálogo con 24 piezas repartidas en tres rarezas: común, rara y legendaria. En V2.18 se ha afinado el anclaje de espada y escudo directamente en sus capas maestras.

La tienda permite filtrar por categoría y rareza y muestra el estado de cada pieza. Los precios pueden ajustarse globalmente desde el Modo Padres.

## Actualización

Las actualizaciones se distribuyen como un único archivo `actualizacion.zip`, que se sube sin descomprimir a la raíz del repositorio. GitHub Actions valida e instala automáticamente el contenido.
